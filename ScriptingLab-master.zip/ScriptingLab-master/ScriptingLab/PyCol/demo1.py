print("Python does not need data type declaration")
age = 20
height = 5.7
name = "Munna Bhai"

# To print()
print("Age is: ", age)
print("Height is: ", height)
print("Name is: ", name)

print("\nMultiple assignements can be done in one line")
age, height, name = 51, 6.0, "Roshan"

print("Age is: ", age)
print("Height is: ", height)
print("Name is: ", name)

print("\nPolymorphic variables - variables are not bound to any data type")
age, height, name = "Roshan", 6.0, 51

print("Age is: ", age)
print("Height is: ", height)
print("Name is: ", name)
