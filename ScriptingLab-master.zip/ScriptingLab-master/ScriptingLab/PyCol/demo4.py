myDictionary = {
	"name": "Archie",
	"identity": "Student",
	"age": 17
}

print(myDictionary)

key = myDictionary["name"]
value = myDictionary.get("name")
print("Key is: ", key)
print("Value is: ", value)
